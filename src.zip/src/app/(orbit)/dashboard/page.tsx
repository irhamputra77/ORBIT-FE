"use client";

import { useRouter } from "next/navigation";
import type { LucideIcon } from "lucide-react";
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ClipboardList,
  Clock3,
  FileCheck2,
  FileText,
  RefreshCw,
  Sparkles,
  UploadCloud,
} from "lucide-react";
import { useServiceBulletins } from "@/features/service-bulletins";
import { featureFlags } from "@/lib/config/features";
import { formatDateTime } from "@/lib/date-time";
import {
  fleetMetrics,
  recentActivities,
  reviewHistory,
  serviceBulletins,
  uploadHistory,
} from "@/data/mockData";
import { useApp } from "../context/AppContext";

type DashboardMetric = {
  label: string;
  value: string | number;
  helper: string;
  color: string;
  icon: LucideIcon;
  path: string;
  disabled?: boolean;
};

function MetricCard({ metric }: { metric: DashboardMetric }) {
  const router = useRouter();
  const Icon = metric.icon;

  return (
    <button
      type="button"
      disabled={metric.disabled}
      onClick={() => !metric.disabled && router.push(metric.path)}
      className="group rounded-xl border border-border bg-card p-4 text-left shadow-sm transition-all enabled:hover:-translate-y-0.5 enabled:hover:border-blue-500/30 enabled:hover:shadow-md disabled:cursor-not-allowed disabled:opacity-70"
    >
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="text-xs font-medium text-muted-foreground">{metric.label}</div>
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg" style={{ background: `${metric.color}15` }}>
          <Icon size={15} style={{ color: metric.color }} />
        </div>
      </div>
      <div className="text-2xl font-bold tracking-tight text-foreground">{metric.value}</div>
      <div className="mt-1 text-[10px] text-muted-foreground">{metric.helper}</div>
    </button>
  );
}

export default function DashboardPage() {
  const router = useRouter();
  const { userRole } = useApp();
  const isManager = userRole === "manager";
  const recentServiceBulletins = useServiceBulletins({
    page: 1,
    limit: 6,
    sortBy: "receivedAt",
    sortOrder: "desc",
  });

  const openSBs = recentServiceBulletins.total;
  const SBESNs = new Set(serviceBulletins.flatMap(item => item.affectedESNs));
  const SBParts = new Set(serviceBulletins.flatMap(item => item.affectedPartNumbers));
  const pendingApprovals = featureFlags.eesApproval ? fleetMetrics.pendingReviews : "—";

  const metrics: DashboardMetric[] = isManager
    ? [
        { label: "Pending EES Approval", value: pendingApprovals, helper: featureFlags.eesApproval ? "Waiting for second engineer review" : "Backend approval belum tersedia", color: "#F59E0B", icon: Clock3, path: "/manager-ees-review", disabled: !featureFlags.eesApproval },
        { label: "Approved EES", value: featureFlags.eesApproval ? fleetMetrics.approvedEES : "—", helper: featureFlags.eesApproval ? "Approved engineering evaluations" : "Backend approval belum tersedia", color: "#10B981", icon: CheckCircle2, path: "/manager-ees-review", disabled: !featureFlags.eesApproval },
        { label: "Service Bulletins", value: recentServiceBulletins.isLoading ? "…" : openSBs, helper: "Records available from AeroCompliance", color: "#0242DB", icon: FileText, path: "/database" },
        { label: "Average Review Time", value: featureFlags.eesApproval ? `${fleetMetrics.avgReviewTime} days` : "—", helper: featureFlags.eesApproval ? "Current EES approval turnaround" : "Backend approval belum tersedia", color: "#818CF8", icon: RefreshCw, path: "/manager-ees-review", disabled: !featureFlags.eesApproval },
      ]
    : [
        { label: "Assigned Reviews", value: 6, helper: "Open, draft, and submitted assignments", color: "#0242DB", icon: ClipboardList, path: "/my-assignment" },
        { label: "Pending Reviews", value: pendingApprovals, helper: featureFlags.eesApproval ? "EES items waiting for review" : "Backend approval belum tersedia", color: "#F59E0B", icon: Clock3, path: "/second-engineer-review", disabled: !featureFlags.eesApproval },
        { label: "Service Bulletins", value: recentServiceBulletins.isLoading ? "…" : openSBs, helper: "Available from AeroCompliance", color: "#00A7D6", icon: FileText, path: "/ees-generator" },
        { label: "Approved EES", value: featureFlags.eesApproval ? fleetMetrics.approvedEES : "—", helper: featureFlags.eesApproval ? "Completed engineering evaluations" : "Backend approval belum tersedia", color: "#10B981", icon: CheckCircle2, path: "/ees-generator", disabled: !featureFlags.eesApproval },
      ];

  const newServiceBulletins = recentServiceBulletins.items.slice(0, 4);
  const workflowActivities = recentActivities.filter(activity => ["EES", "SB"].includes(activity.type)).slice(0, 5);
  const activeDocuments = uploadHistory.filter(document => ["SB", "IQ03", "SVR", "EDS"].includes(document.docType)).slice(0, 5);

  return (
    <div className="mx-auto max-w-[1600px] p-6">
      <header className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="mb-1 flex items-center gap-2">
            <h1 className="text-xl font-bold text-foreground">Engineering Review Dashboard</h1>
            <span className="rounded-full border border-blue-500/20 bg-blue-500/[0.07] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-blue-600">
              {isManager ? "Manager" : "Engineer"}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">
            {isManager
              ? "Monitor submitted EES documents and complete the approval workflow."
              : "Manage assignments, generate EES documents, and validate SB applicability."}
          </p>
          <div className="mt-2 flex items-center gap-2 text-[10px] text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            Workflow services available · Updated {formatDateTime("2026-07-17T09:00:00+07:00")}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isManager && (
            <button
              type="button"
              onClick={() => router.push("/my-assignment")}
              className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-xs font-semibold text-foreground hover:bg-accent"
            >
              <ClipboardList size={13} /> My Assignment
            </button>
          )}
          <button
            type="button"
            disabled={isManager && !featureFlags.eesApproval}
            onClick={() => router.push(isManager ? "/manager-ees-review" : "/ees-generator")}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-br from-[#0242DB] to-[#0E1B93] px-4 py-2.5 text-xs font-semibold text-white shadow-md shadow-blue-900/15"
          >
            {isManager ? <FileCheck2 size={13} /> : <Sparkles size={13} />}
            {isManager ? (featureFlags.eesApproval ? "Open Approval Queue" : "Approval Unavailable") : "Create EES"}
          </button>
        </div>
      </header>

      <section className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {metrics.map(metric => <MetricCard key={metric.label} metric={metric} />)}
      </section>

      <section className="mb-6 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div>
              <h2 className="text-sm font-semibold text-foreground">New Service Bulletins</h2>
              <p className="mt-0.5 text-[10px] text-muted-foreground">Latest SB records received by ORBIT.</p>
            </div>
            <button type="button" onClick={() => router.push("/database")} className="text-[10px] font-semibold text-blue-600">View database</button>
          </div>
          <div className="divide-y divide-border">
            {recentServiceBulletins.isLoading && (
              <div className="px-4 py-8 text-center text-[10px] text-muted-foreground">
                Loading Service Bulletins…
              </div>
            )}
            {!recentServiceBulletins.isLoading && recentServiceBulletins.error && (
              <div className="px-4 py-6 text-center">
                <p className="text-[10px] text-destructive">{recentServiceBulletins.error}</p>
                <button type="button" onClick={recentServiceBulletins.retry} className="mt-2 text-[10px] font-semibold text-blue-600">
                  Try again
                </button>
              </div>
            )}
            {!recentServiceBulletins.isLoading && !recentServiceBulletins.error && newServiceBulletins.length === 0 && (
              <div className="px-4 py-8 text-center text-[10px] text-muted-foreground">
                No Service Bulletins available.
              </div>
            )}
            {newServiceBulletins.map((sb, index) => (
              <button key={sb.id} type="button" onClick={() => router.push("/ees-generator")} className="flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-accent/30">
                <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-blue-500/10 text-[9px] font-bold text-blue-600">SB</div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <div className="truncate font-mono text-[10px] font-semibold text-foreground">{sb.bulletinNumber || "-"}</div>
                    {index === 0 && <span className="rounded-full bg-cyan-500/10 px-1.5 py-0.5 text-[8px] font-bold text-cyan-600">Newest</span>}
                  </div>
                  <div className="mt-0.5 truncate text-[9px] text-muted-foreground">{sb.title}</div>
                  <div className="mt-1 flex items-center gap-2 text-[9px] text-muted-foreground">
                    <span>{sb.aircraftType || "-"}</span><span>·</span><span>{formatDateTime(sb.receivedAt)}</span>
                  </div>
                </div>
                <ArrowRight size={11} className="mt-1 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Latest 2nd Engineer Updates</h2>
              <p className="mt-0.5 text-[10px] text-muted-foreground">Recent approval and review activity.</p>
            </div>
            <button
              type="button"
              disabled={!featureFlags.eesApproval}
              onClick={() => router.push("/second-engineer-review")}
              className="text-[10px] font-semibold text-blue-600 disabled:cursor-not-allowed disabled:text-muted-foreground"
            >
              {featureFlags.eesApproval ? "Open queue" : "Unavailable"}
            </button>
          </div>
          <div className="divide-y divide-border">
            <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
              <Clock3 size={22} className="mb-3 text-muted-foreground" />
              <p className="text-[11px] font-semibold text-foreground">Approval data unavailable</p>
              <p className="mt-1 max-w-64 text-[10px] leading-relaxed text-muted-foreground">
                Data dashboard dan approval belum tersedia dari backend.
              </p>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Reviewed SB This Month</h2>
              <p className="mt-0.5 text-[10px] text-muted-foreground">July 2026 category distribution.</p>
            </div>
            <div className="rounded-xl bg-blue-500/10 px-3 py-2 text-center">
              <div className="text-xl font-bold text-blue-600">—</div>
              <div className="text-[8px] font-semibold uppercase text-blue-600/70">Reviewed</div>
            </div>
          </div>

          <div className="flex min-h-40 flex-col items-center justify-center rounded-xl bg-muted/40 px-6 text-center">
            <FileCheck2 size={22} className="mb-3 text-muted-foreground" />
            <p className="text-[11px] font-semibold text-foreground">Monthly review unavailable</p>
            <p className="mt-1 max-w-64 text-[10px] leading-relaxed text-muted-foreground">
              Statistik review bulanan akan tampil setelah endpoint dashboard tersedia.
            </p>
          </div>
        </div>
      </section>

      {!isManager && (
        <section className="mb-6 overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Active Engineering Review Queue</h2>
              <p className="mt-0.5 text-[10px] text-muted-foreground">Service Bulletins available for EES generation.</p>
            </div>
            <button type="button" onClick={() => router.push("/ees-generator")} className="flex items-center gap-1 text-[10px] font-semibold text-blue-600">
              Open EES Generator <ArrowRight size={11} />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted">
                <tr>
                  {["TDR / EES Number", "Service Bulletin", "Fleet", "Category", "Affected Data", "Status", "Action"].map(header => (
                    <th key={header} className="whitespace-nowrap px-4 py-2.5 text-left text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {serviceBulletins.slice(0, 6).map(sb => (
                  <tr key={sb.id} className="border-t border-border hover:bg-accent/30">
                    <td className="whitespace-nowrap px-4 py-3 font-mono text-[10px] font-semibold text-foreground">{sb.tdr || "Unassigned"}</td>
                    <td className="max-w-64 px-4 py-3">
                      <div className="truncate font-mono text-[10px] font-semibold text-foreground">{sb.id}</div>
                      <div className="mt-0.5 truncate text-[9px] text-muted-foreground">{sb.title}</div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">{sb.fleet}</td>
                    <td className="px-4 py-3"><span className="rounded bg-blue-500/10 px-2 py-0.5 text-[9px] font-semibold text-blue-600">Category {sb.sbCategory}</span></td>
                    <td className="whitespace-nowrap px-4 py-3 text-[10px] text-muted-foreground">{sb.affectedESNs.length} ESN · {sb.affectedPartNumbers.length} PN</td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2 py-0.5 text-[9px] font-semibold ${sb.status === "Open" ? "bg-amber-500/10 text-amber-500" : "bg-emerald-500/10 text-emerald-500"}`}>{sb.status}</span>
                    </td>
                    <td className="px-4 py-3">
                      <button type="button" onClick={() => router.push("/ees-generator")} className="flex items-center gap-1 whitespace-nowrap rounded-lg bg-blue-600 px-2.5 py-1.5 text-[10px] font-semibold text-white">
                        Review <ArrowRight size={10} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <section className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-4 xl:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-foreground">Applicability Data Coverage</h2>
              <p className="mt-0.5 text-[10px] text-muted-foreground">SB requirements prepared for comparison with internal EDS and SVR data.</p>
            </div>
            {!isManager && <button type="button" onClick={() => router.push("/applicability-review")} className="text-[10px] font-semibold text-blue-600">Review applicability</button>}
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { label: "SB Records", value: serviceBulletins.length, icon: FileText, color: "#0242DB" },
              { label: "Unique ESNs", value: SBESNs.size, icon: CheckCircle2, color: "#10B981" },
              { label: "Affected Parts", value: SBParts.size, icon: AlertTriangle, color: "#F59E0B" },
              { label: "Reviewed EES", value: reviewHistory.length, icon: FileCheck2, color: "#818CF8" },
            ].map(item => (
              <div key={item.label} className="rounded-xl border border-border bg-muted/50 p-3">
                <item.icon size={14} style={{ color: item.color }} />
                <div className="mt-3 text-xl font-bold text-foreground">{item.value}</div>
                <div className="mt-0.5 text-[10px] text-muted-foreground">{item.label}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 border-t border-border pt-4">
            <div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              <UploadCloud size={12} /> Processed data sources
            </div>
            <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
              {activeDocuments.map(document => (
                <div key={document.fileName} className="flex items-center gap-3 rounded-lg border border-border px-3 py-2">
                  <span className="rounded bg-blue-500/10 px-1.5 py-0.5 text-[9px] font-bold text-blue-600">{document.docType}</span>
                  <div className="min-w-0 flex-1 truncate text-[10px] font-medium text-foreground">{document.fileName}</div>
                  <span className={`text-[9px] font-semibold ${document.status === "Processed" ? "text-emerald-500" : "text-amber-500"}`}>{document.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground">Recent Workflow Activity</h2>
            <Clock3 size={13} className="text-muted-foreground" />
          </div>
          <div className="space-y-3">
            {workflowActivities.map(activity => (
              <div key={activity.id} className="flex items-start gap-2.5">
                <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-blue-500/10 text-[9px] font-bold text-blue-600">
                  {activity.type}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] leading-relaxed text-foreground">{activity.action}</p>
                  <div className="mt-0.5 text-[9px] text-muted-foreground">{activity.user} · {formatDateTime(activity.time)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
