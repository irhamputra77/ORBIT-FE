import {
  apiJson,
  backendApi,
  backendErrorResponse,
  getAuthorizationHeader,
  proxyBackendBinary,
} from "@/lib/http/backendRoute";

const ID_PATTERN = /^[a-zA-Z0-9_-]{1,128}$/;
const JSON_RESOURCES = new Set(["ai-summary", "applicability", "ees"]);
const BINARY_RESOURCES = new Set(["view", "download"]);
const POST_RESOURCES = new Set(["generate-ees"]);
const PATCH_RESOURCES = new Set(["ees"]);

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string; resource: string }> },
) {
  const { id, resource } = await params;

  if (
    !ID_PATTERN.test(id) ||
    (!JSON_RESOURCES.has(resource) && !BINARY_RESOURCES.has(resource))
  ) {
    return apiJson({ message: "Resource Service Bulletin tidak valid." }, { status: 400 });
  }

  if (BINARY_RESOURCES.has(resource)) {
    return proxyBackendBinary(
      `/api/service-bulletins/${encodeURIComponent(id)}/${resource}`,
      resource === "view" ? "inline" : "attachment",
    );
  }

  const authorization = await getAuthorizationHeader();
  if (!authorization) {
    return apiJson({ message: "Authentication diperlukan." }, { status: 401 });
  }

  try {
    const response = await backendApi.get(
      `/api/service-bulletins/${encodeURIComponent(id)}/${resource}`,
      { headers: { Authorization: authorization } },
    );
    return apiJson(response.data);
  } catch (error) {
    return backendErrorResponse(error);
  }
}

async function mutateServiceBulletinResource(
  request: Request,
  params: Promise<{ id: string; resource: string }>,
  method: "post" | "patch",
) {
  const { id, resource } = await params;
  const allowedResources = method === "post" ? POST_RESOURCES : PATCH_RESOURCES;
  if (!ID_PATTERN.test(id) || !allowedResources.has(resource)) {
    return apiJson({ message: "Resource Service Bulletin tidak valid." }, { status: 400 });
  }

  const authorization = await getAuthorizationHeader();
  if (!authorization) {
    return apiJson({ message: "Authentication diperlukan." }, { status: 401 });
  }

  try {
    const body = await request.json();
    const response = await backendApi[method](
      `/api/service-bulletins/${encodeURIComponent(id)}/${resource}`,
      body,
      { headers: { Authorization: authorization } },
    );
    return apiJson(response.data);
  } catch (error) {
    return backendErrorResponse(error);
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string; resource: string }> },
) {
  return mutateServiceBulletinResource(request, params, "post");
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string; resource: string }> },
) {
  return mutateServiceBulletinResource(request, params, "patch");
}
